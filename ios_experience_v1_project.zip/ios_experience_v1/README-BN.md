# iOS Experience — V1

এটি Android-এর জন্য একটি Native Kotlin + Jetpack Compose Launcher-এর প্রথম সংস্করণ।

## V1-এ যা আছে
- iOS-inspired home screen
- ফোনে Launcher হিসেবে নিবন্ধিত অ্যাপের তালিকা ও আইকন
- অ্যাপ খুলতে আইকনে ট্যাপ
- অ্যাপ সার্চ
- সাধারণ Dock (Phone/Camera/Messages/Chrome নামের অ্যাপ পাওয়া গেলে)
- Android-এর Default Home App নির্বাচন করার অনুরোধ
- GitHub Actions দিয়ে APK build

## প্রয়োজন
- Android 8.0 (API 26) বা নতুন
- Build: JDK 17, Gradle 8.13, Android SDK Platform 35
- Android Studio লাগবে না; GitHub Actions দিয়ে ব্রাউজারে Build করা যায়।

## ফোন থেকে GitHub-এ Build করার নিয়ম
1. https://github.com এ অ্যাকাউন্টে Sign in করো।
2. New repository তৈরি করো, নাম `ios-experience` দাও এবং Public বা Private যেকোনোটি বেছে নাও।
3. এই ZIP extract করে ভেতরের সব ফাইল/ফোল্ডার Repository-র root-এ upload করো। ZIP ফাইলটিকে ZIP হিসেবেই upload করবে না; Extract করে ফাইলগুলো upload করতে হবে।
4. `.github/workflows/build-apk.yml` ফাইলটিও যেন ঠিক এই path-এ থাকে।
5. সব ফাইল `main` branch-এ commit করো।
6. Repository-র Actions tab খোলো। `Build iOS Experience APK` workflow চলবে।
7. Build শেষ হলে সবুজ সফল চিহ্নে চাপ দিয়ে `ios-experience-debug-apk` Artifact ডাউনলোড করো।
8. ZIP Artifact extract করে `app-debug.apk` ফোনে ইনস্টল করো। Android চাইলে browser/files app-কে Install unknown apps অনুমতি দাও।

## Default Launcher করা
APK ইনস্টল করে Open করো। নিচের `Set iOS Experience as default Home app` বাটনে চাপ দাও। Android-এর Home app chooser এ iOS Experience নির্বাচন করো। ভবিষ্যতে Settings > Apps > Default apps > Home app থেকেও বদলানো যাবে (মেনুর নাম ফোনভেদে আলাদা হতে পারে)।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি প্রথম ধাপের Home Screen/Launcher; আসল iOS নয়।
- Lock Screen, Control Center, Notification Center, Dynamic Island এখনো যুক্ত হয়নি।
- Dock-এ আপাতত Phone, Camera, Messages ও Chrome নামে অ্যাপ খোঁজা হয়; ফোনের অ্যাপের নাম আলাদা হলে সেগুলো নাও দেখাতে পারে।
- V1-এর ঘড়ি স্ক্রিন খোলার সময়ের সময় দেখায়; লাইভ ঘড়ি ও উইজেট পরবর্তী সংস্করণে উন্নত করা হবে।
- Android-এর নিজস্ব নিরাপত্তা ও সিস্টেম নিয়ন্ত্রণ অক্ষত থাকে।

## Build error হলে
GitHub Actions > ব্যর্থ Build > Build log থেকে লাল error-এর শেষ 30-50 লাইন কপি করে পাঠাও। Password বা token পাঠাবে না।
